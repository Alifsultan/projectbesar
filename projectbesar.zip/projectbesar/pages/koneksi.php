<?php 

$link=mysqli_connect('localhost','root','','projectbesar');
if (!$link)
{
   die("Koneksi dengan MySQL gagal");
}

?>