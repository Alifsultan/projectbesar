
<?php
    require 'functions.php';
    // cek apakah button submit sudah di tekan atau belum
    if(isset($_POST['submit']))
    {
        //cek sukses data dirubah menggunakan function edit pada functions.php
        if(edit($_POST)>0)
        {
            echo "
            <script>
                alert('data berhasil diperbaharui');
                document.location.href='tables.php';
            </script>
            ";
        } else {
            echo "
            <script>
                alert('data gagal diperbaharui');
                document.location.href='edit.php';
            </script>";
            echo "</br>";
            echo mysqli_error($conn);
        }
    }
?>

<?php
    // ke dalam variabel baru yaitu $id
    $id=$_GET["nim"];
    // var_dump("$nim");

    //query berdasarkan id
    $mhs = query("SELECT * FROM tables WHERE nim=$nim")[0];
    // var_dump($tables);
?>

   
    <li>
        <input type="hidden" nim="id" value="<?= $tables["nim"]; ?>">
    </li>
    
    <ul>
        <tr>
                <!--  for pada label terhubung dengan id jadi jika label nama diklik maka textfield nama akan aktif juga-->
                <td><label for="nim">nim</label></td>
                <!-- untuk pengisian name besar ekcilnya harus sesuai dengan fieldnya-->
                <td><input type="text" name="nim" id="nim" value="<?= $tables["nim"]; ?>"></td>
        </tr>
        <tr>        
            <td><label for="nim">nim</label></td>
            <td><input type="text" name="nim" id="nim" required value="<?= $tables["nim"]; ?>"></td>
        </tr>
        <tr>        
            <td><label for="nama">nama</label></td>
            <td><input type="text" name="nama" id="nama" required value="<?= $tables["nama"]; ?>"></td>
        </tr>
        <tr>
            <td><label for="nama_panggilan">nama_panggilan</label></td>
            <td><input type="text" name="nama_panggilan" id="nama_panggilan" required value="<?= $tables["nama_panggilan"]; ?>"></td>
        </tr>
        <tr>
            <td><label for="alamat">alamat</label></td>
            <td><input type="text" name="alamat" id="alamat" required value="<?= $tables["alamat"]; ?>"></td>
        </tr>
        <tr>
            <td><button type="submit" name="submit"> Update </button></td>
        </tr>
        </ul>
        </form>  
</body>
</html>