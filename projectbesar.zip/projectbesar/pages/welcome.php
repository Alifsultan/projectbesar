<html>
<title>Welcome</title>
<body>
    <p style="text-align: center; font-size: 24px; font-family: Arial;">Selamat datang</p>
    <p style="text-align: center; font-size: 16px; font-family: Arial;">Anda berhasil login</p>
    <br /><br />
    <p style="text-align: center; font-size: 12px; font-family: Arial; text-decoration: underline;"><a href="login.php">Logout</a></p>
</body>

</html>