<?php

session_start();
include 'koneksi.php';

if (isset($_POST['login']))
    {
    $nim=$_POST['nim'];
    $password=$_POST['password'];
    }

$gagal = "";
$error = array();
if (empty($nim))
    {$error['nim'] = "Nim salah";}
else
    {$error['nim'] = "";}
if (empty($password))
    {$error['password'] = "Password salah";}
else
    {$error['password'] = "";}
   
if (!empty($nim) and !empty($password))
    {
    $query=mysqli_query($link,"select * from login where nim ='$nim' and password='$password'");
    $xxx=mysqli_num_rows($query);
    if($xxx==TRUE){
        $_SESSION['nim']=$nim; 
        header("location:welcome.php");   
        }
        else
        {  
            $gagal = "nim atau password salah";
        }
    }
?>

<html>
<head>
    <link rel="stylesheet" type="text/css" href="style.css">     
</head>
<body>
    <div id="kotak">
    <div id="atas">Login SIAKAD</div>
    <div id="bawah">
        <form method="post" action="detected.php">
        <input class="masuk" type="text" autocomplete="off" placeholder="Nim .." name="nim" ><br/>
        <p style="color: red; text-align: center;"><?php echo ($error['nim']);?></p>
        <input class="masuk" type="password" autocomplete="off" placeholder="Password .." name="password"><br/>
        <p style="color: red; text-align: center;"><?php echo ($error['password']);?></p>
        <p style="color: red; text-align: center;"><?php echo $gagal;?></p>
        <input id="tombol" type="submit" name="login" value="Login">
        <p  style = "margin-left: 60px">
		    Not yet a member? <a href="register.php">Sign up</a>
	    </p>
        </form>   
    </div>
    </div>
</body>

</html>